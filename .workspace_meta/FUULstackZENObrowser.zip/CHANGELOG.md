﻿# Changelog
## [0.2.0] - 2026-03-14
### Added
- Complete source code
- 5 scraping tools
- MCP Server 20+ tools
- Terminal console
- Plugin system
