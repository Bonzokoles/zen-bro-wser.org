﻿# Setup Instructions
1. Extract ZIP
2. Copy .env.local.example -> .env.local
3. Add API keys
4. npm install
5. npm run dev
