﻿# ZENO Browser v0.2.0
AI-powered web browser with advanced scraping, automation, and workflow tools.

## Quick Start
1. npm install
2. cp .env.local.example .env.local
3. npm run dev
